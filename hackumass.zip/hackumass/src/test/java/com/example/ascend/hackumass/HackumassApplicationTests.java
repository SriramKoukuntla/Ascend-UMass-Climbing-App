package com.example.ascend.hackumass;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackumassApplicationTests {

	@Test
	void contextLoads() {
	}

}
