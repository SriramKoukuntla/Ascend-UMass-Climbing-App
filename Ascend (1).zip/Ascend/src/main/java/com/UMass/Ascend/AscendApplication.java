package com.UMass.Ascend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AscendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AscendApplication.class, args);
	}

}
